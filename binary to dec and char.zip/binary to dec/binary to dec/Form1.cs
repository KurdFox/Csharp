﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace binary_to_dec
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            int n = int.Parse(textBox1.Text); //binary 
            char ch;
            int p=1;
	        int dec=0,i=1,j,d;

	        for (j=n;j>0;j=j/10)
	        { 
               d = j % 10;
                 if(i==1)
                   p*=1;
                 else
                   p*=2;

	        dec=dec+(d*p);
	        i++;
	        }

            textBox2.Text = dec.ToString();
            ch = Convert.ToChar(dec);
            textBox3.Text = ch.ToString();


        }
    }
}
